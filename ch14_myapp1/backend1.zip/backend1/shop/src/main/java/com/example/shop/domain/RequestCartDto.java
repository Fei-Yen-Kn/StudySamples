package com.example.shop.domain;

import lombok.Data;

@Data
public class RequestCartDto {
    private String username;
    private Long id;
}
