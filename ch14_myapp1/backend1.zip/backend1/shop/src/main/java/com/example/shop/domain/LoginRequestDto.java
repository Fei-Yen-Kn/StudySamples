package com.example.shop.domain;

import lombok.Data;

@Data
public class LoginRequestDto {
    private String username;
    private String password;
}