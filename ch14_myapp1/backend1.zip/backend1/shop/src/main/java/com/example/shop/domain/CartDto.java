package com.example.shop.domain;

import lombok.Data;

@Data
public class CartDto {
	private Long id;
    private String username;
    private Long pid;
}
